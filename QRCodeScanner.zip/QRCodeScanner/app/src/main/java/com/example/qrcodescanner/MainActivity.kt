package com.example.qrcodescanner

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.checkSelfPermission
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.CodeScannerView
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback
import com.budiyev.android.codescanner.ScanMode
import java.util.*
import java.util.jar.Manifest
import androidx.core.content.ContextCompat as ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var codesScanner: CodeScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if(ContextCompat.checkSelfPermission (this, android.Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA), 123)
        } else {
            startScanning()
        }
    }

    private fun startScanning() {
        val scannerView: CodeScannerView = findViewById(R.id.scannerView)
        codesScanner = CodeScanner(this, scannerView)
        codesScanner.camera = CodeScanner.CAMERA_BACK
        codesScanner.formats = CodeScanner.ALL_FORMATS

        codesScanner.autoFocusMode = AutoFocusMode.SAFE
        codesScanner.scanMode = ScanMode.SINGLE
        codesScanner.isAutoFocusEnabled = true
        codesScanner.isFlashEnabled = false

        codesScanner.decodeCallback = DecodeCallback {
            runOnUiThread {
                Toast.makeText(this, "Scan Result: ${it.text}", Toast.LENGTH_SHORT).show()
            }
        }

        codesScanner.errorCallback = ErrorCallback {
            runOnUiThread {
                Toast.makeText(this, "Camera Initialization Error: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }

        scannerView.setOnClickListener {
            codesScanner.startPreview()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 123) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Camera permission Granted!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Camera permission Denied!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::codesScanner.isInitialized) {
            codesScanner.startPreview()
        }
    }

    override fun onPause() {
        if(::codesScanner.isInitialized) {
            codesScanner.releaseResources()
        }
        super.onPause()
    }
}